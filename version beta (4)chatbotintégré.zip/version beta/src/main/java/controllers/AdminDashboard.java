package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class AdminDashboard {

    @FXML private Label systemSettingsLabel;

    @FXML
    public void initialize()
    {
        systemSettingsLabel.setText("Bonjour , Mr L'Administrateur . ✅");
    }
}
