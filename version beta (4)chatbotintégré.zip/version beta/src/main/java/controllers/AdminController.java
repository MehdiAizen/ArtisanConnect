package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class AdminController {
    @FXML private Label welcomeLabel;

    @FXML
    public void initialize() {
        welcomeLabel.setText("Bienvenue dans l'espace Administrateur !");
    }
}