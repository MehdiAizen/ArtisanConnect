package controllers;

import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Duration;
import models.LoginModel;
import java.io.IOException;
import java.util.Random;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;
    @FXML private Label chatbotLabel;
    @FXML private Button chatbotButton;

    // GESTION DE LA CONNEXION
    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        LoginModel loginModel = new LoginModel();

        if (loginModel.authenticate(username, password)) {
            try {
                String fxmlPath = determineDashboardPath(username);
                errorLabel.setText("");
                loadDashboard(fxmlPath);
            } catch (IOException e) {
                errorLabel.setText("Erreur de chargement du dashboard.");
            }
        } else {
            errorLabel.setText("Identifiants incorrects.");
        }
    }

    // GESTION DU CHATBOT
    @FXML
    private void handleChatbot() {
        chatbotLabel.setText("Veuillez patienter...");
        PauseTransition delay = new PauseTransition(Duration.seconds(2));
        delay.setOnFinished(event -> chatbotLabel.setText(getRandomChatbotResponse()));
        delay.play();

        PauseTransition openChatDelay = new PauseTransition(Duration.seconds(1));
        openChatDelay.setOnFinished(event -> openChatbotWindow());
        openChatDelay.play();
    }

    // METHODES UTILITAIRES
    private String determineDashboardPath(String username) throws IOException {
        if (username.startsWith("admin")) return "/views/admin_dashboard.fxml";
        if (username.startsWith("client")) return "/views/client_dashboard.fxml";
        if (username.startsWith("artisan")) return "/views/artisan_dashboard.fxml";
        throw new IOException("Rôle non reconnu");
    }

    private void loadDashboard(String fxmlPath) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));
        Stage stage = (Stage) usernameField.getScene().getWindow();
        Scene scene = new Scene(root);

        // Animation de fondu
        scene.getRoot().setOpacity(0);
        FadeTransition fade = new FadeTransition(Duration.seconds(1), scene.getRoot());
        fade.setFromValue(0);
        fade.setToValue(1);

        stage.setScene(scene);
        fade.play();
    }

    private void openChatbotWindow() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/chatbot.fxml"));
            Parent root = loader.load();

            Stage chatStage = new Stage();
            chatStage.setTitle("Assistant Virtuel");
            chatStage.setScene(new Scene(root, 400, 500));
            chatStage.show();
        } catch (IOException e) {
            chatbotLabel.setText("Erreur d'ouverture du chatbot");
            e.printStackTrace();
        }
    }

    private String getRandomChatbotResponse() {
        String[] responses = {
                "Bonjour ! Comment puis-je vous aider ? 🌟",
                "Recherche en cours... 🔍",
                "Connexion à un expert en cours 📞",
                "Je consulte nos ressources... 📚",
                "Un instant, je vous trouve la meilleure solution ⏳"
        };
        return responses[new Random().nextInt(responses.length)];
    }
}