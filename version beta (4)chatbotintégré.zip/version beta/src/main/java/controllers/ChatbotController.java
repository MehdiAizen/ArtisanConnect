package controllers;

import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.util.Duration;
import models.Atelier;
import java.time.LocalTime;
import java.util.*;

public class ChatbotController {
    private final Map<String, String> reponses = new HashMap<>();
    private final List<Atelier> ateliersDisponibles = new ArrayList<>();
    private final Map<String, List<String>> motsClesAteliers = new HashMap<>();

    @FXML private TextArea chatArea;
    @FXML private TextField userInput;
    @FXML private ListView<Atelier> suggestionsList; // Modifié en ListView<Atelier>
    @FXML private Button btnReserver;

    @FXML
    public void initialize() {
        initialiserDonnees();
        configurerUI();
        afficherMessageBot("Bonjour ! Je suis l'assistant ArtisanConnect. Comment puis-je vous aider ?");
    }

    private void initialiserDonnees() {
        // Réponses améliorées
        reponses.put("bonjour", "Bonjour ! Prêt à découvrir l'artisanat tunisien ? 🎨");
        reponses.put("heure", "Il est actuellement : " + LocalTime.now().toString().substring(0, 8));
        reponses.put("contact", "📞 Contactez-nous au 50 481 607");
        reponses.put("merci", "Je vous en prie ! 😊");
        reponses.put("aide", """
            Je peux :
            - Donner l'heure 🕒
            - Fournir nos contacts 📞
            - Recommander des ateliers 🎭
            - Gérer vos réservations ✅"""
        );

        // Configuration des ateliers
        ateliersDisponibles.addAll(Arrays.asList(
                new Atelier("Poterie Traditionnelle", "Nabeul", "Atelier de 2h", 45.0),
                new Atelier("Tissage de Tapis", "Kairouan", "Initiation au métier ancestral", 60.0),
                new Atelier("Bijoux en Argent", "Djerba", "Création de bijoux berbères", 55.0)
        ));

        // Mots-clés étendus
        motsClesAteliers.put("poterie", Arrays.asList("poterie", "argile", "céramique", "terre"));
        motsClesAteliers.put("tissage", Arrays.asList("tissage", "tapis", "laine", "textile"));
        motsClesAteliers.put("bijoux", Arrays.asList("bijoux", "argent", "collier", "bracelet"));
    }

    private void configurerUI() {
        suggestionsList.setCellFactory(lv -> new ListCell<Atelier>() {
            @Override
            protected void updateItem(Atelier atelier, boolean empty) {
                super.updateItem(atelier, empty);
                setText(empty ? "" : atelier.getNom() + " - " + atelier.getPrix() + " TND");
            }
        });
    }

    @FXML
    private void handleSendMessage() {
        String message = userInput.getText().trim();
        if (!message.isEmpty()) {
            afficherMessageUtilisateur(message);
            traiterMessage(message.toLowerCase());
            userInput.clear();
        }
    }

    private void traiterMessage(String message) {
        String reponse = detecterIntention(message);
        afficherMessageBot(reponse);
    }

    private String detecterIntention(String message) {
        // Phrases courantes
        if (message.matches(".*\\b(salut|coucou|hello)\\b.*")) {
            return reponses.get("bonjour");
        }
        if (message.contains("prix") || message.contains("coût")) {
            return "Les prix varient entre 45 et 75 TND selon les ateliers 💰";
        }

        // Réservation
        if (message.matches(".*\\b(réserver|reserver|inscrire)\\b.*")) {
            suggestionsList.setItems(FXCollections.observableArrayList(ateliersDisponibles));
            return "Choisissez un atelier dans la liste :";
        }

        // Recherche par catégorie
        for (Map.Entry<String, List<String>> entry : motsClesAteliers.entrySet()) {
            for (String motCle : entry.getValue()) {
                if (message.contains(motCle)) {
                    return trouverAteliersParCategorie(entry.getKey());
                }
            }
        }

        return reponses.getOrDefault(message, "Je n'ai pas compris. Tapez 'aide' pour les options ❌");
    }

    private String trouverAteliersParCategorie(String categorie) {
        StringBuilder resultat = new StringBuilder("Ateliers de " + categorie + " 🎨:\n");
        ateliersDisponibles.stream()
                .filter(a -> a.getNom().toLowerCase().contains(categorie))
                .forEach(a -> resultat.append("→ ").append(a).append("\n"));
        return resultat.toString();
    }

    private void afficherMessageUtilisateur(String message) {
        chatArea.appendText("Vous: " + message + "\n");
    }

    private void afficherMessageBot(String message) {
        PauseTransition pause = new PauseTransition(Duration.seconds(0.7));
        pause.setOnFinished(e -> chatArea.appendText("Assistant: " + message + "\n\n"));
        pause.play();
    }

    @FXML
    private void handleReservation() {
        Atelier selected = suggestionsList.getSelectionModel().getSelectedItem();
        if (selected != null) {
            afficherConfirmationReservation(selected);
        } else {
            afficherMessageBot("Veuillez d'abord sélectionner un atelier ! ❌");
        }
    }

    private void afficherConfirmationReservation(Atelier atelier) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation de réservation");
        alert.setHeaderText("Réservation pour : " + atelier.getNom());
        alert.setContentText("📍 " + atelier.getLocalisation() + "\n💵 Prix: " + atelier.getPrix() + " TND");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            afficherMessageBot("✅ Réservation confirmée pour :\n" + atelier);
        }
    }
}