package models;

import java.util.HashMap;
import java.util.Map;

public class ChatbotModel {
    private final Map<String, String> reponses = new HashMap<>();

    public ChatbotModel() {
        // Initialisation des réponses
        reponses.put("bonjour", "Bonjour ! Comment puis-je vous aider ?");
        reponses.put("heure", "Il est actuellement : " + java.time.LocalTime.now());
        reponses.put("contact", "Contactez-nous au 50 481 607.");
        reponses.put("merci", "Je vous en prie ! 😊");

    }

    public String getReponse(String message) {

        message = message.toLowerCase();

        // Vérifier si un des mots-clés est contenu dans le message
        for (Map.Entry<String, String> entry : reponses.entrySet()) {
            if (message.contains(entry.getKey())) {
                return entry.getValue();
            }
        }

        return "Je ne comprends pas. Pouvez-vous reformuler ?";
    }
}
