package models;

import java.util.HashMap;
import java.util.Map;

public class LoginModel {
    private final Map<String, String> users = new HashMap<>();

    public LoginModel() {
        // Administrateurs
        users.put("admin", "admin");

        // Clients
        users.put("client1", "client123");
        users.put("client2", "client456");

        // Artisans
        users.put("artisan1", "artisan789");
        users.put("artisan2", "artisan000");
    }

    public boolean authenticate(String username, String password) {
        return users.containsKey(username) && users.get(username).equals(password);
    }
}