package com.example.artisanconnect.controller;

import com.example.artisanconnect.model.Order;
import com.example.artisanconnect.model.OrderTracker;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class OrderTrackingController {
    @FXML private Label orderIdLabel;
    @FXML private Label statusLabel;

    public void loadOrder(String orderId) {
        Order order = OrderTracker.getInstance().findOrder(orderId);

        if (order != null) {
            orderIdLabel.setText("Commande #" + order.getOrderId());
            statusLabel.setText("Statut : " + order.getStatus());
        }
    }

    @FXML
    private void returnToHome() {
        // Implémentez la navigation vers l'accueil si nécessaire
    }
}