package models;

import java.util.ArrayList;
import java.util.List;

public class ReviewModel {
    private static final List<Review> reviews = new ArrayList<>();

    static {
        reviews.add(new Review(1, "Super travail de l'artisan !", 5));
        reviews.add(new Review(2, "Mauvaise expérience, très déçu.", 2));
        reviews.add(new Review(3, "Correct, mais peut mieux faire.", 3));
    }

    public static List<Review> getPendingReviews() {
        List<Review> pendingReviews = new ArrayList<>();
        for (Review review : reviews) {
            if (review.getStatus().equals("pending")) {
                pendingReviews.add(review);
            }
        }
        return pendingReviews;
    }

    public static void approveReview(int reviewId) {
        for (Review review : reviews) {
            if (review.getId() == reviewId) {
                review.approve();
                notifyObservers();
                break;
            }
        }
    }

    public static void rejectReview(int reviewId) {
        for (Review review : reviews) {
            if (review.getId() == reviewId) {
                review.reject();
                notifyObservers();
                break;
            }
        }
    }

    private static void notifyObservers() {
        // Simule la mise à jour des avis (ex: base de données ou UI)
        System.out.println("Les avis ont été mis à jour !");
    }
}
