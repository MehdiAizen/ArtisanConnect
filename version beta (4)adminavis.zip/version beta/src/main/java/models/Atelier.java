package models;

public class Atelier {
    private final String nom;
    private final String localisation;
    private final String description;
    private final double prix;
    private boolean actif;

    public Atelier(String nom, String localisation, String description, double prix) {
        this.nom = nom;
        this.localisation = localisation;
        this.description = description;
        this.prix = prix;
        this.actif = true;
    }

    // Getters
    public String getNom() { return nom; }
    public String getLocalisation() { return localisation; }
    public String getDescription() { return description; }
    public double getPrix() { return prix; }
    public boolean isActif() { return actif; }

    // Setter
    public void setActif(boolean actif) { this.actif = actif; }
}