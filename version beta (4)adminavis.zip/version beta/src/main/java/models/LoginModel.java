package models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LoginModel {
    private static final Map<String, UserModel> users = new HashMap<>();

    static {
        users.put("admin", new UserModel("admin", "admin", "admin"));
        users.put("client", new UserModel("client", "client123", "client"));
        users.put("artisan", new UserModel("artisan", "artisan789", "artisan"));
    }

    public static String getUserRole(String username) {
        UserModel user = users.get(username);
        return user != null ? user.getRole() : "unknown";
    }

    public boolean authenticate(String username, String password) {
        UserModel user = users.get(username);
        return user != null && user.getPassword().equals(password);
    }

    public static List<UserModel> getUsers() {
        return new ArrayList<>(users.values());
    }

    public static void addUser(UserModel user) {
        users.put(user.getUsername(), user);
    }

    public static void removeUser(String username) {
        users.remove(username);
    }
}