package models;

import java.util.ArrayList;
import java.util.List;

public class AtelierModel {
    private static final List<Atelier> ateliers = new ArrayList<>();

    static {
        ateliers.add(new Atelier("Poterie", "Nabeul", "Atelier débutant", 45.0));
        ateliers.add(new Atelier("Tissage", "Kairouan", "Techniques avancées", 60.0));
    }

    public static List<Atelier> getAteliers() {
        return new ArrayList<>(ateliers);
    }

    public static void toggleAtelier(String nom) {
        ateliers.stream()
                .filter(a -> a.getNom().equals(nom))
                .findFirst()
                .ifPresent(a -> a.setActif(!a.isActif()));
    }

    public static long countActive() {
        return ateliers.stream().filter(Atelier::isActif).count();
    }
}