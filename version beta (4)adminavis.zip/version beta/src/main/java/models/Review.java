package models;

import javafx.beans.property.*;

public class Review {
    private final IntegerProperty id;
    private final StringProperty content;
    private final IntegerProperty rating;
    private final StringProperty status;

    public Review(int id, String content, int rating) {
        this.id = new SimpleIntegerProperty(id);
        this.content = new SimpleStringProperty(content);
        this.rating = new SimpleIntegerProperty(rating);
        this.status = new SimpleStringProperty("pending");
    }

    public int getId() { return id.get(); }
    public String getContent() { return content.get(); }
    public int getRating() { return rating.get(); }
    public String getStatus() { return status.get(); }

    public void approve() { status.set("approved"); }
    public void reject() { status.set("rejected"); }

    public IntegerProperty idProperty() { return id; }
    public StringProperty contentProperty() { return content; }
    public IntegerProperty ratingProperty() { return rating; }
    public StringProperty statusProperty() { return status; }
}
