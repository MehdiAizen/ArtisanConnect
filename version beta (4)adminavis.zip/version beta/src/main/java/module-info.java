module com.example.versionbeta {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.example.versionbeta to javafx.fxml;
    opens controllers to javafx.fxml;
    opens models to javafx.base;

    exports com.example.versionbeta;
    exports controllers;
    exports models;
}