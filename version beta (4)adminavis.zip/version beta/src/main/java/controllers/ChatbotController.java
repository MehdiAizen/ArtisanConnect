package controllers;

import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.util.Duration;
import models.Atelier;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ChatbotController {
    private final Map<String, String> reponses = new HashMap<>();
    private final List<Atelier> ateliersDisponibles = new ArrayList<>();
    private final Map<String, List<String>> motsClesAteliers = new HashMap<>();

    @FXML private TextArea chatArea;
    @FXML private TextField userInput;
    @FXML private ListView<Atelier> suggestionsList;
    @FXML private Button btnReserver;

    @FXML
    public void initialize() {
        initialiserDonnees();
        configurerUI();
        afficherMessageBot("Bonjour ! Je suis l'assistant ArtisanConnect. Comment puis-je vous aider ?");
    }

    private void initialiserDonnees() {
        // Configuration des réponses
        reponses.put("aide", """
            🛠️ Je peux :
            - Donner l'heure actuelle 🕒
            - Fournir nos coordonnées 📞
            - Recommander des ateliers 🎨
            - Gérer vos réservations 📅
            Tapez un mot-clé pour commencer !""");

        reponses.put("bonjour", "👋 Bonjour ! Prêt à découvrir l'artisanat tunisien ?");
        reponses.put("contact", "📞 Contact : 50 481 607 | 📧 Email : contact@artisanconnect.tn");
        reponses.put("merci", "Je vous en prie ! 😊 N'hésitez pas si vous avez d'autres questions.");

        // Configuration des ateliers
        ateliersDisponibles.addAll(Arrays.asList(
                new Atelier("Poterie Traditionnelle", "Nabeul", "Création de poteries en argile", 45.0),
                new Atelier("Tissage de Tapis", "Kairouan", "Apprentissage des motifs traditionnels", 60.0),
                new Atelier("Bijoux Berbères", "Djerba", "Fabrication de bijoux en argent", 55.0)
        ));

        // Configuration des mots-clés
        motsClesAteliers.put("poterie", Arrays.asList("poterie", "argile", "céramique"));
        motsClesAteliers.put("tissage", Arrays.asList("tissage", "tapis", "laine"));
        motsClesAteliers.put("bijoux", Arrays.asList("bijou", "argent", "collier"));
    }

    private void configurerUI() {
        // Personnalisation de l'affichage des ateliers
        suggestionsList.setCellFactory(lv -> new ListCell<Atelier>() {
            @Override
            protected void updateItem(Atelier atelier, boolean empty) {
                super.updateItem(atelier, empty);
                if (empty || atelier == null) {
                    setText(null);
                } else {
                    setText(String.format("🏺 %s\n📍 %s | 💵 %.1f TND",
                            atelier.getNom(),
                            atelier.getLocalisation(),
                            atelier.getPrix()));
                }
            }
        });
    }

    @FXML
    private void handleSendMessage() {
        String message = userInput.getText().trim();
        if (!message.isEmpty()) {
            afficherMessageUtilisateur(message);
            traiterMessage(message.toLowerCase());
            userInput.clear();
        }
    }

    private void traiterMessage(String message) {
        String reponse = detecterIntention(message);
        afficherMessageBot(reponse);
    }

    private String detecterIntention(String message) {
        // Détection des intentions spéciales
        if (message.contains("heure")) {
            return "🕒 Il est " + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
        }
        if (message.matches(".*(reserver|réservation|inscrire).*")) {
            suggestionsList.setItems(FXCollections.observableArrayList(ateliersDisponibles));
            return "✅ Sélectionnez un atelier dans la liste :";
        }

        // Recherche par catégorie
        for (Map.Entry<String, List<String>> entry : motsClesAteliers.entrySet()) {
            if (entry.getValue().stream().anyMatch(message::contains)) {
                return genererReponseAteliers(entry.getKey());
            }
        }

        return reponses.getOrDefault(message, "❌ Je n'ai pas compris. Tapez 'aide' pour les options disponibles.");
    }

    private String genererReponseAteliers(String categorie) {
        StringBuilder sb = new StringBuilder();
        sb.append("🎉 Ateliers de ").append(categorie).append(" :\n");
        ateliersDisponibles.stream()
                .filter(a -> a.getNom().toLowerCase().contains(categorie))
                .forEach(a -> sb.append(String.format("\n→ %s (%s) - %.1f TND",
                        a.getNom(),
                        a.getLocalisation(),
                        a.getPrix())));
        return sb.toString();
    }

    private void afficherMessageUtilisateur(String message) {
        chatArea.appendText("\n👤 Vous : " + message + "\n");
    }

    private void afficherMessageBot(String message) {
        PauseTransition pause = new PauseTransition(Duration.seconds(0.5));
        pause.setOnFinished(e -> {
            chatArea.appendText("🤖 Assistant : " + message + "\n");
            chatArea.appendText("―".repeat(50) + "\n");
        });
        pause.play();
    }

    @FXML
    private void handleReservation() {
        Atelier selected = suggestionsList.getSelectionModel().getSelectedItem();
        if (selected != null) {
            afficherConfirmationReservation(selected);
        } else {
            afficherMessageBot("⚠️ Veuillez d'abord sélectionner un atelier !");
        }
    }

    private void afficherConfirmationReservation(Atelier atelier) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation de réservation");
        alert.setHeaderText("Confirmez votre réservation pour :");
        alert.setContentText(String.format(
                "🏺 %s\n📍 %s\n⏱ Durée : %s\n💵 Prix : %.1f TND",
                atelier.getNom(),
                atelier.getLocalisation(),
                atelier.getDescription(),
                atelier.getPrix()));

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            afficherMessageBot("🎉 Réservation confirmée !\nUn email de confirmation vous a été envoyé.");
        }
    }
}