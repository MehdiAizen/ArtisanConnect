package controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import models.LoginModel;
import java.io.IOException;
import java.net.URL;

public class LoginController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;

    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        if (new LoginModel().authenticate(username, password)) {
            try {
                String role = LoginModel.getUserRole(username);
                String fxmlPath = switch (role) {
                    case "admin" -> "/views/admin_dashboard.fxml";
                    case "client" -> "/views/client_dashboard.fxml";
                    case "artisan" -> "/views/artisan_dashboard.fxml";
                    default -> throw new Exception("Rôle inconnu");
                };

                URL resource = getClass().getResource(fxmlPath);
                if (resource == null) {
                    throw new IOException("Fichier FXML introuvable : " + fxmlPath);
                }

                FXMLLoader loader = new FXMLLoader(resource);
                Parent root = loader.load();
                Stage stage = (Stage) usernameField.getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();

            } catch (Exception e) {
                errorLabel.setText("Erreur de chargement : " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            errorLabel.setText("Identifiants incorrects !");
        }
    }

    @FXML
    private void handleChatbot() {
        try {
            String fxmlPath = "/views/chatbot.fxml";
            URL resource = getClass().getResource(fxmlPath);
            if (resource == null) {
                throw new IOException("Fichier chatbot.fxml introuvable !");
            }

            FXMLLoader loader = new FXMLLoader(resource);
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Assistant Virtuel");
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            errorLabel.setText("Erreur d'ouverture du chatbot : " + e.getMessage());
            e.printStackTrace();
        }
    }
}
