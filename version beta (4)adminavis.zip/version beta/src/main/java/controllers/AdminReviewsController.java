package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Review;
import models.ReviewModel;

public class AdminReviewsController {
    @FXML private TableView<Review> reviewsTable;
    @FXML private TableColumn<Review, Integer> colId;
    @FXML private TableColumn<Review, String> colContent;
    @FXML private TableColumn<Review, Integer> colRating;
    @FXML private Label statusLabel;
    private ObservableList<Review> reviewList;

    @FXML
    public void initialize() {
        System.out.println("initialize() exécuté !");
        colId.setCellValueFactory(cellData -> cellData.getValue().idProperty().asObject());
        colContent.setCellValueFactory(cellData -> cellData.getValue().contentProperty());
        colRating.setCellValueFactory(cellData -> cellData.getValue().ratingProperty().asObject());

        loadPendingReviews();
    }

    private void loadPendingReviews() {
        reviewList = FXCollections.observableArrayList(ReviewModel.getPendingReviews());
        reviewsTable.setItems(reviewList);
        System.out.println("Données chargées : " + reviewList);
    }

    @FXML
    private void approveReview() {
        Review selectedReview = reviewsTable.getSelectionModel().getSelectedItem();
        if (selectedReview != null) {
            ReviewModel.approveReview(selectedReview.getId());
            reviewList.remove(selectedReview);
            statusLabel.setText("Avis approuvé !");
        } else {
            statusLabel.setText("Veuillez sélectionner un avis.");
        }
    }

    @FXML
    private void rejectReview() {
        Review selectedReview = reviewsTable.getSelectionModel().getSelectedItem();
        if (selectedReview != null) {
            ReviewModel.rejectReview(selectedReview.getId());
            reviewList.remove(selectedReview);
            statusLabel.setText("Avis rejeté !");
        } else {
            statusLabel.setText("Veuillez sélectionner un avis.");
        }
    }
}
