package controllers;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.AnchorPane;
import javafx.scene.chart.PieChart;
import javafx.stage.Stage;
import models.*;

import java.io.IOException;
import java.util.Optional;

public class AdminController {

    @FXML private TableView<UserModel> userTable;
    @FXML private TableView<Atelier> atelierTable;
    @FXML private PieChart statsChart;
    @FXML private AnchorPane reviewsPane;

    @FXML
    public void initialize() {
        // Chargement des données
        userTable.setItems(FXCollections.observableArrayList(LoginModel.getUsers()));
        atelierTable.setItems(FXCollections.observableArrayList(AtelierModel.getAteliers()));

        // Chargement de la vue "Avis"
        loadAdminReviews();

        // Mise à jour des statistiques
        updateStats();
    }

    private void updateStats() {
        statsChart.getData().clear();
        statsChart.getData().addAll(
                new PieChart.Data("Utilisateurs (" + LoginModel.getUsers().size() + ")", LoginModel.getUsers().size()),
                new PieChart.Data("Ateliers actifs (" + AtelierModel.countActive() + ")", AtelierModel.countActive())
        );
    }

    private void loadAdminReviews() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/admin_reviews.fxml"));
            AnchorPane reviewsView = loader.load();
            reviewsPane.getChildren().setAll(reviewsView);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void supprimerUser() {
        UserModel selected = userTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            LoginModel.removeUser(selected.getUsername());
            userTable.getItems().remove(selected);
            updateStats();
        } else {
            showAlert("Suppression impossible", "Veuillez sélectionner un utilisateur.", Alert.AlertType.WARNING);
        }
    }

    @FXML
    private void toggleAtelier() {
        Atelier selected = atelierTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            AtelierModel.toggleAtelier(selected.getNom());
            atelierTable.refresh();
            updateStats();
        } else {
            showAlert("Action impossible", "Veuillez sélectionner un atelier.", Alert.AlertType.WARNING);
        }
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
