package com.example.artisanconnect.model;

import javafx.collections.ObservableList;

public class Order {
    private final String orderId;
    private final ObservableList<CartItem> items;
    private final double total;
    private String status;

    public Order(String orderId, ObservableList<CartItem> items, double total, String status) {
        this.orderId = orderId;
        this.items = items;
        this.total = total;
        this.status = status;
    }

    // Getters
    public String getOrderId() { return orderId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}