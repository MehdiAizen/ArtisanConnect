module com.example.versionbeta {
    requires javafx.controls;
    requires javafx.fxml;

    opens controllers to javafx.fxml;
    exports com.example.versionbeta;
}
