package controllers;

import javafx.animation.PauseTransition;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.util.Duration;
import java.util.HashMap;
import java.util.Map;

public class ChatbotController {
    private final Map<String, String> reponses = new HashMap<>();

    @FXML private TextArea chatArea;
    @FXML private TextField userInput;
    @FXML private Button sendButton;

    @FXML
    private void initialize() {
        // Initialisation des réponses
        reponses.put("bonjour", "Bonjour ! Comment puis-je vous aider ?");
        reponses.put("heure", "Il est actuellement : " + java.time.LocalTime.now());
        reponses.put("contact", "Contactez-nous au 50 481 607.");
        reponses.put("merci", "Je vous en prie ! 😊");

        // Configuration initiale
        chatArea.appendText("Chatbot: Bonjour ! Posez-moi une question.\n");
    }

    @FXML
    private void sendMessage() {
        String message = userInput.getText().trim();
        if (!message.isEmpty()) {
            chatArea.appendText("Vous: " + message + "\n");
            userInput.clear();
            repondre(message.toLowerCase());
        }
    }

    private void repondre(String message) {
        String reponse = reponses.entrySet().stream()
                .filter(e -> message.contains(e.getKey()))
                .findFirst()
                .map(Map.Entry::getValue)
                .orElse("Je ne comprends pas. Pouvez-vous reformuler ?");

        // Ajout d'un délai avant la réponse avec PauseTransition
        PauseTransition delay = new PauseTransition(Duration.seconds(1));
        delay.setOnFinished(event -> chatArea.appendText("Chatbot: " + reponse + "\n"));
        delay.play();
    }
}
