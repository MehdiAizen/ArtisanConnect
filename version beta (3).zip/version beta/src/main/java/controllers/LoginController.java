package controllers;

import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.util.Random;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;
    @FXML private Label chatbotLabel;
    @FXML private Button chatbotButton;

    /**
     * Vérifie les identifiants et charge le tableau de bord si l'authentification est réussie.
     */
    @FXML
    private void handleLogin() {
        if ("admin".equals(usernameField.getText()) && "admin".equals(passwordField.getText())) {
            try {
                errorLabel.setText(""); // Réinitialiser le message d'erreur
                loadDashboard("/views/admin_dashboard.fxml");
            } catch (IOException e) {
                errorLabel.setText("Erreur de chargement du dashboard.");
            }
        } else {
            errorLabel.setText("Identifiants incorrects.");
        }
    }

    /**
     * Affiche un message intelligent lorsque l'utilisateur clique sur le bouton Chatbot.
     */
    @FXML
    private void handleChatbot() {
        chatbotLabel.setText("Veuillez patienter...");

        // Ajoute un délai avant d'afficher un message pour plus de réalisme
        PauseTransition delay = new PauseTransition(Duration.seconds(2));
        delay.setOnFinished(event -> chatbotLabel.setText(getRandomChatbotResponse()));
        delay.play();

        // Ouvrir une fenêtre chatbot après 1 seconde
        PauseTransition openChatDelay = new PauseTransition(Duration.seconds(1));
        openChatDelay.setOnFinished(event -> openChatbotWindow());
        openChatDelay.play();
    }

    /**
     * Charge le fichier FXML du tableau de bord.
     */
    private void loadDashboard(String fxmlPath) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));
        Stage stage = (Stage) usernameField.getScene().getWindow();
        Scene scene = new Scene(root);
        scene.getRoot().setOpacity(0); // Démarre transparent
        stage.setScene(scene);

        // Animation de fondu
        FadeTransition fade = new FadeTransition(Duration.seconds(1), scene.getRoot());
        fade.setFromValue(0);
        fade.setToValue(1);
        fade.play();
    }

    /**
     * Ouvre une nouvelle fenêtre contenant l'interface du chatbot.
     */
    private void openChatbotWindow() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/chatbot.fxml"));
            Parent root = loader.load();

            Stage chatStage = new Stage();
            chatStage.setTitle("Chatbot");
            chatStage.setScene(new Scene(root, 400, 500));
            chatStage.show();
        } catch (IOException e) {
            chatbotLabel.setText("Impossible d'ouvrir le chatbot.");
            e.printStackTrace();
        }
    }

    /**
     * Génère une réponse aléatoire du chatbot.
     */
    private String getRandomChatbotResponse() {
        String[] responses = {
                "Bonjour ! Comment puis-je vous aider ?",
                "Un instant, je recherche la réponse pour vous...",
                "Je vous mets en relation avec un agent.",
                "Notre assistant est en ligne, posez votre question !",
                "Je suis là pour vous aider. Que voulez-vous savoir ?"
        };
        Random rand = new Random();
        return responses[rand.nextInt(responses.length)];
    }
}