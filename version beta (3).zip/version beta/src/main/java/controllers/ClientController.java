package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class ClientController {
    @FXML private Label welcomeLabel;

    @FXML
    public void initialize() {
        welcomeLabel.setText("Bienvenue dans l'espace Client !");
    }
}